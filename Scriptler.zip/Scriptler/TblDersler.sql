USE [ProjeDb]
GO

/****** Object:  Table [dbo].[TblDersler]    Script Date: 10.04.2021 14:08:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TblDersler](
	[D_Kodu] [nvarchar](20) NOT NULL,
	[D_Adi] [nvarchar](35) NOT NULL,
	[D_BolumKodu] [nchar](10) NOT NULL,
	[D_sinif] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_TblDersler] PRIMARY KEY CLUSTERED 
(
	[D_Kodu] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[TblDersler]  WITH CHECK ADD  CONSTRAINT [FK_TblDersler_TblBolumler] FOREIGN KEY([D_BolumKodu])
REFERENCES [dbo].[TblBolumler] ([Kod])
GO

ALTER TABLE [dbo].[TblDersler] CHECK CONSTRAINT [FK_TblDersler_TblBolumler]
GO


