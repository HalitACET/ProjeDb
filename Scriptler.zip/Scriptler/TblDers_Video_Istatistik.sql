USE [ProjeDb]
GO

/****** Object:  Table [dbo].[TblDers_Video_Istatistik]    Script Date: 10.04.2021 14:08:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TblDers_Video_Istatistik](
	[SNo] [smallint] IDENTITY(1,1) NOT NULL,
	[D_Video] [nchar](100) NOT NULL,
	[DogruSay] [tinyint] NOT NULL,
	[YanlisSay] [tinyint] NOT NULL,
 CONSTRAINT [PK_TblDers_Video_Istatistik] PRIMARY KEY CLUSTERED 
(
	[D_Video] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[TblDers_Video_Istatistik]  WITH CHECK ADD  CONSTRAINT [FK_TblDers_Video_Istatistik_TblDers_Video] FOREIGN KEY([D_Video])
REFERENCES [dbo].[TblDers_Video] ([D_Video])
GO

ALTER TABLE [dbo].[TblDers_Video_Istatistik] CHECK CONSTRAINT [FK_TblDers_Video_Istatistik_TblDers_Video]
GO


