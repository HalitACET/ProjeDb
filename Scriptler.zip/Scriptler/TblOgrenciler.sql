USE [ProjeDb]
GO

/****** Object:  Table [dbo].[TblOgrenciler]    Script Date: 10.04.2021 14:09:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TblOgrenciler](
	[O_Tc_Kimlik] [nvarchar](11) NOT NULL,
	[O_Ad] [nvarchar](20) NOT NULL,
	[O_Soyad] [nvarchar](20) NOT NULL,
	[O_Sifre] [nvarchar](12) NOT NULL,
	[O_E-mail] [nvarchar](35) NOT NULL,
	[O_Bolum] [nvarchar](35) NOT NULL,
	[O_Sinif] [nvarchar](10) NOT NULL,
 CONSTRAINT [PK_TblOgrenciler] PRIMARY KEY CLUSTERED 
(
	[O_Tc_Kimlik] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


