USE [ProjeDb]
GO

/****** Object:  Table [dbo].[TblOgrenci_Video_Istatistik]    Script Date: 10.04.2021 14:09:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TblOgrenci_Video_Istatistik](
	[SNo] [smallint] IDENTITY(1,1) NOT NULL,
	[O_Tc_Kimlik] [nvarchar](11) NOT NULL,
	[D_Kodu] [nvarchar](20) NOT NULL,
	[D_Video] [nchar](100) NOT NULL,
	[DogruSay] [tinyint] NOT NULL,
	[YanlisSay] [tinyint] NOT NULL,
 CONSTRAINT [PK_TblOgrenci_Video_Istatistik] PRIMARY KEY CLUSTERED 
(
	[SNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[TblOgrenci_Video_Istatistik]  WITH CHECK ADD  CONSTRAINT [FK_TblOgrenci_Video_Istatistik_TblDers_Video] FOREIGN KEY([D_Video])
REFERENCES [dbo].[TblDers_Video] ([D_Video])
GO

ALTER TABLE [dbo].[TblOgrenci_Video_Istatistik] CHECK CONSTRAINT [FK_TblOgrenci_Video_Istatistik_TblDers_Video]
GO

ALTER TABLE [dbo].[TblOgrenci_Video_Istatistik]  WITH CHECK ADD  CONSTRAINT [FK_TblOgrenci_Video_Istatistik_TblDers_Video_Istatistik] FOREIGN KEY([D_Video])
REFERENCES [dbo].[TblDers_Video_Istatistik] ([D_Video])
GO

ALTER TABLE [dbo].[TblOgrenci_Video_Istatistik] CHECK CONSTRAINT [FK_TblOgrenci_Video_Istatistik_TblDers_Video_Istatistik]
GO

ALTER TABLE [dbo].[TblOgrenci_Video_Istatistik]  WITH CHECK ADD  CONSTRAINT [FK_TblOgrenci_Video_Istatistik_TblDersler] FOREIGN KEY([D_Kodu])
REFERENCES [dbo].[TblDersler] ([D_Kodu])
GO

ALTER TABLE [dbo].[TblOgrenci_Video_Istatistik] CHECK CONSTRAINT [FK_TblOgrenci_Video_Istatistik_TblDersler]
GO

ALTER TABLE [dbo].[TblOgrenci_Video_Istatistik]  WITH CHECK ADD  CONSTRAINT [FK_TblOgrenci_Video_Istatistik_TblOgrenciler] FOREIGN KEY([O_Tc_Kimlik])
REFERENCES [dbo].[TblOgrenciler] ([O_Tc_Kimlik])
GO

ALTER TABLE [dbo].[TblOgrenci_Video_Istatistik] CHECK CONSTRAINT [FK_TblOgrenci_Video_Istatistik_TblOgrenciler]
GO


