USE [ProjeDb]
GO

/****** Object:  Table [dbo].[TblVideo_Sorular�]    Script Date: 10.04.2021 14:09:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TblVideo_Sorular�](
	[SNo] [smallint] IDENTITY(1,1) NOT NULL,
	[D_Video] [nchar](100) NOT NULL,
	[Soru] [nvarchar](500) NOT NULL,
	[Sec1] [nvarchar](100) NOT NULL,
	[Sec2] [nvarchar](100) NOT NULL,
	[Sec3] [nvarchar](100) NOT NULL,
	[Sec4] [nvarchar](100) NOT NULL,
	[Sec5] [nvarchar](100) NOT NULL,
	[DCevap] [nchar](2) NOT NULL,
	[Soru_Dakika] [tinyint] NOT NULL,
 CONSTRAINT [PK_TblVideo_Sorular�] PRIMARY KEY CLUSTERED 
(
	[SNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[TblVideo_Sorular�]  WITH CHECK ADD  CONSTRAINT [FK_TblVideo_Sorular�_TblDers_Video] FOREIGN KEY([D_Video])
REFERENCES [dbo].[TblDers_Video] ([D_Video])
GO

ALTER TABLE [dbo].[TblVideo_Sorular�] CHECK CONSTRAINT [FK_TblVideo_Sorular�_TblDers_Video]
GO


