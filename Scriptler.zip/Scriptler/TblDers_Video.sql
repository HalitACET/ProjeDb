USE [ProjeDb]
GO

/****** Object:  Table [dbo].[TblDers_Video]    Script Date: 10.04.2021 14:07:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TblDers_Video](
	[D_Kodu] [nvarchar](20) NOT NULL,
	[D_Hafta] [nvarchar](20) NOT NULL,
	[D_No] [tinyint] NOT NULL,
	[D_Video] [nchar](100) NOT NULL,
 CONSTRAINT [PK_TblDers_Video] PRIMARY KEY CLUSTERED 
(
	[D_Video] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[TblDers_Video]  WITH CHECK ADD  CONSTRAINT [FK_TblDers_Video_TblDersler] FOREIGN KEY([D_Kodu])
REFERENCES [dbo].[TblDersler] ([D_Kodu])
GO

ALTER TABLE [dbo].[TblDers_Video] CHECK CONSTRAINT [FK_TblDers_Video_TblDersler]
GO


